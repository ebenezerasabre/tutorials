

module.exports = {
  user: "postgres",
  host: "localhost",
  database: "bonystore",
  password: "1995",
  port: 5432,
};

